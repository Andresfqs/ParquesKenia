package Forms;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import Excepciones.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import Enums.Arma;
import parques.ReservaCaza;
import Menu.FormMenu;

public class FormReservaCaza {

	private JFrame frmReservaDeCaza;
	private JTextField txtNombre;
	private JTextField txtExtencion;
	private JTextField txtUbicacion;
	private JTextField txtNumeroespecies;
	private JTextField txtTemperatura;
	private JTextField txtCapacidadvisitantes;
	private JTextField txtCostoingreso;
	
	public void setVisible(boolean visibilidad)
	{
		frmReservaDeCaza.setVisible(visibilidad);
	}
	/**
	 * Create the application.
	 */
	public FormReservaCaza() {
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmReservaDeCaza = new JFrame();
		frmReservaDeCaza.setTitle("Reserva de caza");
		frmReservaDeCaza.setBounds(100, 100, 330, 430);
		frmReservaDeCaza.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmReservaDeCaza.getContentPane().setLayout(null);
		
		JLabel lblRegistroReservaDe = new JLabel("Registro de una reserva de caza");
		lblRegistroReservaDe.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistroReservaDe.setBounds(41, 27, 210, 14);
		frmReservaDeCaza.getContentPane().add(lblRegistroReservaDe);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(28, 77, 46, 14);
		frmReservaDeCaza.getContentPane().add(lblNombre);
		
		JLabel lblExtencinEnKm = new JLabel("Extenci\u00F3n en km");
		lblExtencinEnKm.setBounds(28, 102, 111, 14);
		frmReservaDeCaza.getContentPane().add(lblExtencinEnKm);
		
		JLabel lblUbicacion = new JLabel("Ubicaci\u00F3n");
		lblUbicacion.setBounds(28, 127, 68, 14);
		frmReservaDeCaza.getContentPane().add(lblUbicacion);
		
		JLabel lblNumeroEspecies = new JLabel("Numero de especies");
		lblNumeroEspecies.setBounds(28, 152, 121, 14);
		frmReservaDeCaza.getContentPane().add(lblNumeroEspecies);
		
		JLabel lblTemperatura = new JLabel("Temperatura");
		lblTemperatura.setBounds(28, 177, 86, 14);
		frmReservaDeCaza.getContentPane().add(lblTemperatura);
		
		JLabel lblCapacidadVisitantes = new JLabel("Capacidad visitantes");
		lblCapacidadVisitantes.setBounds(28, 202, 126, 14);
		frmReservaDeCaza.getContentPane().add(lblCapacidadVisitantes);
		
		JLabel lblCostoIngreso = new JLabel("Costo ingreso");
		lblCostoIngreso.setBounds(28, 227, 103, 14);
		frmReservaDeCaza.getContentPane().add(lblCostoIngreso);
		
		JLabel lblArma = new JLabel("Arma");
		lblArma.setBounds(28, 252, 46, 14);
		frmReservaDeCaza.getContentPane().add(lblArma);
		
		JLabel lblConfirmarregistro = new JLabel("Confirmar Registro");
		lblConfirmarregistro.setBounds(10, 345, 304, 14);
		frmReservaDeCaza.getContentPane().add(lblConfirmarregistro);
		lblConfirmarregistro.setVisible(false);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(190, 74, 86, 20);
		frmReservaDeCaza.getContentPane().add(txtNombre);
		txtNombre.setColumns(10);
		
		txtExtencion = new JTextField();
		txtExtencion.setBounds(190, 99, 86, 20);
		frmReservaDeCaza.getContentPane().add(txtExtencion);
		txtExtencion.setColumns(10);
		
		txtUbicacion = new JTextField();
		txtUbicacion.setBounds(190, 124, 86, 20);
		frmReservaDeCaza.getContentPane().add(txtUbicacion);
		txtUbicacion.setColumns(10);
		
		txtNumeroespecies = new JTextField();
		txtNumeroespecies.setBounds(190, 149, 86, 20);
		frmReservaDeCaza.getContentPane().add(txtNumeroespecies);
		txtNumeroespecies.setColumns(10);
		
		txtTemperatura = new JTextField();
		txtTemperatura.setBounds(190, 174, 86, 20);
		frmReservaDeCaza.getContentPane().add(txtTemperatura);
		txtTemperatura.setColumns(10);
		
		txtCapacidadvisitantes = new JTextField();
		txtCapacidadvisitantes.setBounds(190, 199, 86, 20);
		frmReservaDeCaza.getContentPane().add(txtCapacidadvisitantes);
		txtCapacidadvisitantes.setColumns(10);
		
		txtCostoingreso = new JTextField();
		txtCostoingreso.setBounds(190, 224, 86, 20);
		frmReservaDeCaza.getContentPane().add(txtCostoingreso);
		txtCostoingreso.setColumns(10);
		
		JComboBox comboBoxArma = new JComboBox();
		comboBoxArma.setModel(new DefaultComboBoxModel(new String[] {"Lanza", "Arco", "Escopeta"}));
		comboBoxArma.setBounds(190, 249, 86, 20);
		frmReservaDeCaza.getContentPane().add(comboBoxArma);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{	
					String fecha_creacion = ObtenerFecha();
					ReservaCaza reservacaza = new ReservaCaza(txtNombre.getText().toString(), Double.parseDouble(txtExtencion.getText()),txtUbicacion.getText().toString(), Integer.parseInt(txtNumeroespecies.getText()), Double.parseDouble(txtTemperatura.getText()),Integer.parseInt(txtCapacidadvisitantes.getText()), Double.parseDouble(txtCostoingreso.getText()), Arma.valueOf((comboBoxArma.getSelectedItem().toString())),fecha_creacion);
					int validar=ReservaCaza.BuscarReserva(txtNombre.getText(), FormMenu.Lista_ReservasCaza);
					if (validar==-1)
					{
						FormMenu.Lista_ReservasCaza.add(reservacaza);
						reservacaza.Guardar();
						if(!FormMenu.Lista_ReservasCaza.add(reservacaza)){
							lblConfirmarregistro.setVisible(true);
							lblConfirmarregistro.setText("No se pudo registrar el parque");
						}
						if(FormMenu.Lista_ReservasCaza.add(reservacaza)){
							lblConfirmarregistro.setVisible(true);
							lblConfirmarregistro.setText("Se registro el parque");	
							txtNombre.setText("");
							txtExtencion.setText("");
							txtUbicacion.setText("");
							txtNumeroespecies.setText("");
							txtTemperatura.setText("");
							txtCapacidadvisitantes.setText("");
							txtCostoingreso.setText("");
						}
					}
					else{
						lblConfirmarregistro.setVisible(true);
						lblConfirmarregistro.setText("no puede dos veces");
					}
				}
				catch (NumberFormatException | EspaciosNegativosOVacios e1) {
					lblConfirmarregistro.setVisible(true);
					lblConfirmarregistro.setText("Ingrese los datos nuevamente de manera correcta");
				}
				catch (Exception e) {
					lblConfirmarregistro.setVisible(true);
					lblConfirmarregistro.setText("No se ha realizado la acci�n");
				}
			}
		});
		btnRegistrar.setBounds(28, 298, 89, 23);
		frmReservaDeCaza.getContentPane().add(btnRegistrar);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmReservaDeCaza.setVisible(false);
			}
		});
		btnCerrar.setBounds(173, 298, 89, 23);
		frmReservaDeCaza.getContentPane().add(btnCerrar);
	}
	public String ObtenerFecha(){

		Calendar fecha = Calendar.getInstance();
		int ano = fecha.get(Calendar.YEAR);
		int mes = fecha.get(Calendar.MONTH);
		int dia = fecha.get(Calendar.DAY_OF_MONTH);
		int hora = fecha.get(Calendar.HOUR);
		int minuto = fecha.get(Calendar.MINUTE);
		int segundo = fecha.get(Calendar.SECOND);
		String txt = ano + "/" + mes + "/" + dia + " " + hora + ":" + minuto + ":" + segundo;
		return txt;
		
	}
}
