package Forms;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import Excepciones.*;
import parques.AreaTerrestre;
import Menu.FormMenu;

public class FormAreaTerrestre {

	private JFrame frmAreaTerrestre;
	private JTextField txtNombre;
	private JTextField txtExtencionKm;
	private JTextField txtUbicacion;
	private JTextField txtNumeroEspecies;
	private JTextField txtTemperatura;
	private JTextField txtCapacidadVisitantes;
	private JTextField txtDonacionGobierno;
	private JTextField txtNombreOng;
	private JTextField txtTipoTerreno;
	public void setVisible(boolean visibilidad)
	{
		frmAreaTerrestre.setVisible(visibilidad);
	}
	/**
	 * Create the application.
	 */
	public FormAreaTerrestre() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAreaTerrestre = new JFrame();
		frmAreaTerrestre.setTitle("Area terrestre");
		frmAreaTerrestre.setBounds(100, 100, 369, 430);
		frmAreaTerrestre.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAreaTerrestre.getContentPane().setLayout(null);
		
		JLabel lblRegistroDereas = new JLabel("Registro de \u00E1reas terrestre");
		lblRegistroDereas.setBounds(88, 21, 205, 14);
		frmAreaTerrestre.getContentPane().add(lblRegistroDereas);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(29, 61, 46, 14);
		frmAreaTerrestre.getContentPane().add(lblNombre);
		
		JLabel lblExtencionEnKm = new JLabel("Extencion en km");
		lblExtencionEnKm.setBounds(29, 86, 172, 14);
		frmAreaTerrestre.getContentPane().add(lblExtencionEnKm);
		
		JLabel lblUbicacin = new JLabel("Ubicaci\u00F3n");
		lblUbicacin.setBounds(29, 111, 82, 14);
		frmAreaTerrestre.getContentPane().add(lblUbicacin);
		
		JLabel lblNumeroDeEspecies = new JLabel("Numero de especies");
		lblNumeroDeEspecies.setBounds(29, 136, 123, 14);
		frmAreaTerrestre.getContentPane().add(lblNumeroDeEspecies);
		
		JLabel lblTemperatura = new JLabel("Temperatura");
		lblTemperatura.setBounds(29, 161, 82, 14);
		frmAreaTerrestre.getContentPane().add(lblTemperatura);
		
		JLabel lblCapacidadDeVisitantes = new JLabel("Capacidad de visitantes");
		lblCapacidadDeVisitantes.setBounds(29, 186, 187, 14);
		frmAreaTerrestre.getContentPane().add(lblCapacidadDeVisitantes);
		
		JLabel lblValorDeLa = new JLabel("Valor de la donacion del gobierno");
		lblValorDeLa.setBounds(29, 211, 275, 14);
		frmAreaTerrestre.getContentPane().add(lblValorDeLa);
		
		JLabel lblNombreDeLa = new JLabel("Nombre de la ONG");
		lblNombreDeLa.setBounds(29, 236, 104, 14);
		frmAreaTerrestre.getContentPane().add(lblNombreDeLa);
		
		JLabel lblTipoDeTerreno = new JLabel("Tipo de terreno");
		lblTipoDeTerreno.setBounds(29, 261, 104, 14);
		frmAreaTerrestre.getContentPane().add(lblTipoDeTerreno);
		
		JLabel lblConfirmarRegistro = new JLabel("Confirmar registro");
		lblConfirmarRegistro.setBounds(10, 347, 333, 34);
		frmAreaTerrestre.getContentPane().add(lblConfirmarRegistro);
		lblConfirmarRegistro.setVisible(false);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(257, 55, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtNombre);
		txtNombre.setColumns(10);
		
		txtExtencionKm = new JTextField();
		txtExtencionKm.setBounds(257, 80, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtExtencionKm);
		txtExtencionKm.setColumns(10);
		
		txtUbicacion = new JTextField();
		txtUbicacion.setBounds(257, 105, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtUbicacion);
		txtUbicacion.setColumns(10);
		
		txtNumeroEspecies = new JTextField();
		txtNumeroEspecies.setBounds(257, 130, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtNumeroEspecies);
		txtNumeroEspecies.setColumns(10);
		
		txtTemperatura = new JTextField();
		txtTemperatura.setBounds(257, 155, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtTemperatura);
		txtTemperatura.setColumns(10);
		
		txtCapacidadVisitantes = new JTextField();
		txtCapacidadVisitantes.setBounds(257, 180, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtCapacidadVisitantes);
		txtCapacidadVisitantes.setColumns(10);
		
		txtDonacionGobierno = new JTextField();
		txtDonacionGobierno.setBounds(257, 205, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtDonacionGobierno);
		txtDonacionGobierno.setColumns(10);
		
		txtNombreOng = new JTextField();
		txtNombreOng.setBounds(257, 230, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtNombreOng);
		txtNombreOng.setColumns(10);
		
		txtTipoTerreno = new JTextField();
		txtTipoTerreno.setBounds(257, 255, 86, 20);
		frmAreaTerrestre.getContentPane().add(txtTipoTerreno);
		txtTipoTerreno.setColumns(10);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String fecha_creacion = ObtenerFecha();
					AreaTerrestre areaterrestre = new AreaTerrestre(txtNombre.getText().toString(), Double.parseDouble(txtExtencionKm.getText()),txtUbicacion.getText().toString(),Integer.parseInt(txtNumeroEspecies.getText()), Double.parseDouble(txtTemperatura.getText()),Integer.parseInt(txtCapacidadVisitantes.getText()), Double.parseDouble(txtDonacionGobierno.getText()), txtNombreOng.getText().toString(),txtTipoTerreno.getText().toString(), fecha_creacion);
					int validar=AreaTerrestre.BuscarAreaTerrestre(txtNombre.getText(), FormMenu.Lista_AreaTerrestre);
					if(validar==-1)
					{
						FormMenu.Lista_AreaTerrestre.add(areaterrestre);
						areaterrestre.Guardar();
						if(!FormMenu.Lista_AreaTerrestre.add(areaterrestre)){
							lblConfirmarRegistro.setVisible(true);
							lblConfirmarRegistro.setText("No se pudo registrar el parque");
						}
						if(FormMenu.Lista_AreaTerrestre.add(areaterrestre)){
							lblConfirmarRegistro.setVisible(true);
							lblConfirmarRegistro.setText("Se registro el parque");
							txtNombre.setText("");
							txtExtencionKm.setText("");
							txtUbicacion.setText("");
							txtNumeroEspecies.setText("");
							txtTemperatura.setText("");
							txtCapacidadVisitantes.setText("");
							txtDonacionGobierno.setText("");
							txtNombreOng.setText("");
							txtTipoTerreno.setText("");
						}
					}
					else{
						lblConfirmarRegistro.setVisible(true);
						lblConfirmarRegistro.setText("no puede dos veces");
					}
				}
				catch (NumberFormatException | EspaciosNegativosOVacios e1) {
					lblConfirmarRegistro.setVisible(true);
					lblConfirmarRegistro.setText("Ingrese los datos nuevamente de manera correcta");
				}
				catch (Exception exception){
					lblConfirmarRegistro.setVisible(true);
					lblConfirmarRegistro.setText("No se ha realizado la acci�n");
				}
			}
		});
		btnRegistrar.setBounds(57, 315, 89, 23);
		frmAreaTerrestre.getContentPane().add(btnRegistrar);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmAreaTerrestre.setVisible(false);
			}
		});
		btnCerrar.setBounds(204, 315, 89, 23);
		frmAreaTerrestre.getContentPane().add(btnCerrar);
		
	}
	public String ObtenerFecha(){

		Calendar fecha = Calendar.getInstance();
		int ano = fecha.get(Calendar.YEAR);
		int mes = fecha.get(Calendar.MONTH);
		int dia = fecha.get(Calendar.DAY_OF_MONTH);
		int hora = fecha.get(Calendar.HOUR);
		int minuto = fecha.get(Calendar.MINUTE);
		int segundo = fecha.get(Calendar.SECOND);
		String txt = ano + "/" + mes + "/" + dia + " " + hora + ":" + minuto + ":" + segundo;
		return txt;
		
	}

}
