package Forms;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import Excepciones.*;
import parques.AreaAcuatica;
import Menu.FormMenu;

public class FormAreaAcuatica {

	private JFrame frmAreaAcuatica;
	private JTextField txtNombre;
	private JTextField txtExtencionkm;
	private JTextField txtUbicacion;
	private JTextField txtNumeroEspecies;
	private JTextField txtTemperatura;
	private JTextField txtCapacidadVisitantes;
	private JTextField txtValorDonacionGobierno;
	private JTextField txtNombreong;
	private JTextField txtNumerolagos;
	public void setVisible(boolean visibilidad)
	{
		frmAreaAcuatica.setVisible(visibilidad);
	}
	/**
	 * Create the application.
	 */
	public FormAreaAcuatica() {
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAreaAcuatica = new JFrame();
		frmAreaAcuatica.setTitle("Area acuatica");
		frmAreaAcuatica.setBounds(100, 100, 367, 430);
		frmAreaAcuatica.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAreaAcuatica.getContentPane().setLayout(null);
		
		JLabel lblAreaAcuatica = new JLabel("Registro de un \u00E1rea acuatica");
		lblAreaAcuatica.setHorizontalAlignment(SwingConstants.CENTER);
		lblAreaAcuatica.setBounds(48, 24, 249, 14);
		frmAreaAcuatica.getContentPane().add(lblAreaAcuatica);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(27, 52, 46, 14);
		frmAreaAcuatica.getContentPane().add(lblNombre);
		
		JLabel lblExtencionEnKm = new JLabel("Extencion en km");
		lblExtencionEnKm.setBounds(27, 77, 128, 14);
		frmAreaAcuatica.getContentPane().add(lblExtencionEnKm);
		
		JLabel lblUbicacin = new JLabel("Ubicaci\u00F3n");
		lblUbicacin.setBounds(27, 102, 57, 14);
		frmAreaAcuatica.getContentPane().add(lblUbicacin);
		
		JLabel lblNumeroDeEspecies = new JLabel("Numero de especies ");
		lblNumeroDeEspecies.setBounds(27, 127, 158, 14);
		frmAreaAcuatica.getContentPane().add(lblNumeroDeEspecies);
		
		JLabel lblTemperatura = new JLabel("Temperatura");
		lblTemperatura.setBounds(27, 152, 96, 14);
		frmAreaAcuatica.getContentPane().add(lblTemperatura);
		
		JLabel lblCapacidadEVisitantes = new JLabel("Capacidad de visitantes");
		lblCapacidadEVisitantes.setBounds(27, 177, 213, 14);
		frmAreaAcuatica.getContentPane().add(lblCapacidadEVisitantes);
		
		JLabel lblValorDeLa = new JLabel("Valor de la donacion del gobierno");
		lblValorDeLa.setBounds(27, 202, 235, 14);
		frmAreaAcuatica.getContentPane().add(lblValorDeLa);
		
		JLabel lblNombreDeLa = new JLabel("Nombre de la ONG");
		lblNombreDeLa.setBounds(27, 227, 158, 14);
		frmAreaAcuatica.getContentPane().add(lblNombreDeLa);
		
		JLabel lblNumeroDeLagos = new JLabel("Numero de lagos");
		lblNumeroDeLagos.setBounds(27, 252, 128, 14);
		frmAreaAcuatica.getContentPane().add(lblNumeroDeLagos);
		
		JLabel lblConfirmarRegistro = new JLabel("Confirmar Registro");
		lblConfirmarRegistro.setBounds(10, 331, 341, 35);
		frmAreaAcuatica.getContentPane().add(lblConfirmarRegistro);
		lblConfirmarRegistro.setVisible(false);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(234, 49, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtNombre);
		txtNombre.setColumns(10);
		
		txtExtencionkm = new JTextField();
		txtExtencionkm.setBounds(234, 74, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtExtencionkm);
		txtExtencionkm.setColumns(10);
		
		txtUbicacion = new JTextField();
		txtUbicacion.setBounds(234, 99, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtUbicacion);
		txtUbicacion.setColumns(10);
		
		txtNumeroEspecies = new JTextField();
		txtNumeroEspecies.setBounds(234, 124, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtNumeroEspecies);
		txtNumeroEspecies.setColumns(10);
		
		txtTemperatura = new JTextField();
		txtTemperatura.setBounds(234, 149, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtTemperatura);
		txtTemperatura.setColumns(10);
		
		txtCapacidadVisitantes = new JTextField();
		txtCapacidadVisitantes.setBounds(234, 174, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtCapacidadVisitantes);
		txtCapacidadVisitantes.setColumns(10);
		
		txtValorDonacionGobierno = new JTextField();
		txtValorDonacionGobierno.setBounds(234, 202, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtValorDonacionGobierno);
		txtValorDonacionGobierno.setColumns(10);
		
		txtNombreong = new JTextField();
		txtNombreong.setBounds(234, 227, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtNombreong);
		txtNombreong.setColumns(10);
		
		txtNumerolagos = new JTextField();
		txtNumerolagos.setBounds(234, 252, 86, 20);
		frmAreaAcuatica.getContentPane().add(txtNumerolagos);
		txtNumerolagos.setColumns(10);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String fecha_creacion = ObtenerFecha();
					AreaAcuatica areaAcuatica = new AreaAcuatica(txtNombre.getText().toString(), Double.parseDouble(txtExtencionkm.getText()),txtUbicacion.getText().toString(),Integer.parseInt(txtNumeroEspecies.getText()), Double.parseDouble(txtTemperatura.getText()),Integer.parseInt(txtCapacidadVisitantes.getText()), Double.parseDouble(txtValorDonacionGobierno.getText()), txtNombreong.getText().toString(),Integer.parseInt(txtNumerolagos.getText()),fecha_creacion);
					int validar=AreaAcuatica.BuscarAreaAcuatica(txtNombre.getText(), FormMenu.Lista_AreaAcuatica);
					if (validar==-1)
					{
						FormMenu.Lista_AreaAcuatica.add(areaAcuatica);
						areaAcuatica.Guardar();
					
						if(!FormMenu.Lista_AreaAcuatica.add(areaAcuatica)){
							lblConfirmarRegistro.setVisible(true);
							lblConfirmarRegistro.setText("No se pudo registrar el parque");
						}
						if(FormMenu.Lista_AreaAcuatica.add(areaAcuatica)){
						lblConfirmarRegistro.setVisible(true);
						lblConfirmarRegistro.setText("Se registro el parque");
						txtNombre.setText("");
						txtExtencionkm.setText("");
						txtUbicacion.setText("");
						txtNumeroEspecies.setText("");
						txtTemperatura.setText("");
						txtCapacidadVisitantes.setText("");
						txtValorDonacionGobierno.setText("");
						txtNombreong.setText("");
						txtNumerolagos.setText("");
						}
				    }
					else{
						lblConfirmarRegistro.setVisible(true);
						lblConfirmarRegistro.setText("solo puede registrar 1 vez el parque");
					}
				} 
				catch (NumberFormatException | EspaciosNegativosOVacios e) {
					lblConfirmarRegistro.setVisible(true);
					lblConfirmarRegistro.setText("Ingrese los datos nuevamente de manera correcta");
				}
				catch (Exception exception){
					lblConfirmarRegistro.setVisible(true);
					lblConfirmarRegistro.setText("No se ha realizado la acci�n");
				}
				
			}
		});
		btnRegistrar.setBounds(48, 297, 89, 23);
		frmAreaAcuatica.getContentPane().add(btnRegistrar);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmAreaAcuatica.setVisible(false);
			}
		});
		btnCerrar.setBounds(173, 297, 89, 23);
		frmAreaAcuatica.getContentPane().add(btnCerrar);
		
	}
	public String ObtenerFecha(){

		Calendar fecha = Calendar.getInstance();
		int ano = fecha.get(Calendar.YEAR);
		int mes = fecha.get(Calendar.MONTH);
		int dia = fecha.get(Calendar.DAY_OF_MONTH);
		int hora = fecha.get(Calendar.HOUR);
		int minuto = fecha.get(Calendar.MINUTE);
		int segundo = fecha.get(Calendar.SECOND);
		String txt = ano + "/" + mes + "/" + dia + " " + hora + ":" + minuto + ":" + segundo;
		return txt;
		
	}
}
