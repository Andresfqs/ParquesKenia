package Forms;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import Excepciones.*;
import parques.AreaSinClasificar;
import Menu.FormMenu;

public class FormAreaSinClasificar {

	private JFrame frmAreaSinClasificar;
	private JTextField txtNombre;
	private JTextField txtExtencionKm;
	private JTextField txtUbicacion;
	private JTextField txtNumeroEspecies;
	private JTextField txtTemperatura;
	private JTextField txtCapacidadVisitantes;
	private JTextField txtCostoIngreso;
	public void setVisible(boolean visibilidad)
	{
		frmAreaSinClasificar.setVisible(visibilidad);
	}

	/**
	 * Create the application.
	 */
	public FormAreaSinClasificar() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAreaSinClasificar = new JFrame();
		frmAreaSinClasificar.setTitle("Area sin clasificar");
		frmAreaSinClasificar.setBounds(100, 100, 330, 430);
		frmAreaSinClasificar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAreaSinClasificar.getContentPane().setLayout(null);
		
		JLabel lblRegistroDereas = new JLabel("Registro de \u00E1reas sin clasificar");
		lblRegistroDereas.setBounds(53, 27, 206, 14);
		frmAreaSinClasificar.getContentPane().add(lblRegistroDereas);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(27, 68, 56, 14);
		frmAreaSinClasificar.getContentPane().add(lblNombre);
		
		JLabel lblExtencionEnKm = new JLabel("Extencion en km");
		lblExtencionEnKm.setBounds(27, 93, 141, 14);
		frmAreaSinClasificar.getContentPane().add(lblExtencionEnKm);
		
		JLabel lblUbicacin = new JLabel("Ubicaci\u00F3n");
		lblUbicacin.setBounds(27, 118, 56, 14);
		frmAreaSinClasificar.getContentPane().add(lblUbicacin);
		
		JLabel lblNmeroDeEspeciesr = new JLabel("N\u00FAmero de especies");
		lblNmeroDeEspeciesr.setBounds(27, 143, 155, 14);
		frmAreaSinClasificar.getContentPane().add(lblNmeroDeEspeciesr);
		
		JLabel lblTemperatura = new JLabel("Temperatura");
		lblTemperatura.setBounds(27, 168, 108, 14);
		frmAreaSinClasificar.getContentPane().add(lblTemperatura);
		
		JLabel lblCapacidadDeVisitantes = new JLabel("Capacidad de visitantes");
		lblCapacidadDeVisitantes.setBounds(27, 193, 141, 14);
		frmAreaSinClasificar.getContentPane().add(lblCapacidadDeVisitantes);
		
		JLabel lblCostoIngreso = new JLabel("Costo ingreso");
		lblCostoIngreso.setBounds(27, 218, 120, 14);
		frmAreaSinClasificar.getContentPane().add(lblCostoIngreso);
		
		JLabel lblConfirmarRegistro = new JLabel("Confirmar registro");
		lblConfirmarRegistro.setBounds(10, 333, 294, 29);
		frmAreaSinClasificar.getContentPane().add(lblConfirmarRegistro);
		lblConfirmarRegistro.setVisible(false);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(173, 65, 86, 20);
		frmAreaSinClasificar.getContentPane().add(txtNombre);
		txtNombre.setColumns(10);
		
		txtExtencionKm = new JTextField();
		txtExtencionKm.setBounds(173, 90, 86, 20);
		frmAreaSinClasificar.getContentPane().add(txtExtencionKm);
		txtExtencionKm.setColumns(10);
		
		txtUbicacion = new JTextField();
		txtUbicacion.setBounds(173, 115, 86, 20);
		frmAreaSinClasificar.getContentPane().add(txtUbicacion);
		txtUbicacion.setColumns(10);
		
		txtNumeroEspecies = new JTextField();
		txtNumeroEspecies.setBounds(173, 140, 86, 20);
		frmAreaSinClasificar.getContentPane().add(txtNumeroEspecies);
		txtNumeroEspecies.setColumns(10);
		
		txtTemperatura = new JTextField();
		txtTemperatura.setBounds(173, 165, 86, 20);
		frmAreaSinClasificar.getContentPane().add(txtTemperatura);
		txtTemperatura.setColumns(10);
		
		txtCapacidadVisitantes = new JTextField();
		txtCapacidadVisitantes.setBounds(173, 190, 86, 20);
		frmAreaSinClasificar.getContentPane().add(txtCapacidadVisitantes);
		txtCapacidadVisitantes.setColumns(10);
		
		txtCostoIngreso = new JTextField();
		txtCostoIngreso.setBounds(173, 218, 86, 20);
		frmAreaSinClasificar.getContentPane().add(txtCostoIngreso);
		txtCostoIngreso.setColumns(10);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String fecha_creacion = ObtenerFecha();
					AreaSinClasificar areasinclasificar = new AreaSinClasificar(txtNombre.getText().toString(), Double.parseDouble(txtExtencionKm.getText()),txtUbicacion.getText().toString(), Integer.parseInt(txtNumeroEspecies.getText()), Double.parseDouble(txtTemperatura.getText()),Integer.parseInt(txtCapacidadVisitantes.getText()), Double.parseDouble(txtCostoIngreso.getText()), fecha_creacion);
					int validar=AreaSinClasificar.BuscarAreaSinClasificar(txtNombre.getText(), FormMenu.Lista_AreaSinClasificar);
					if (validar==-1)
					{
						FormMenu.Lista_AreaSinClasificar.add(areasinclasificar);
						areasinclasificar.Guardar();
						if(!FormMenu.Lista_AreaSinClasificar.add(areasinclasificar)){
							lblConfirmarRegistro.setVisible(true);
							lblConfirmarRegistro.setText("No se pudo registrar el parque");
						}
						if(FormMenu.Lista_AreaSinClasificar.add(areasinclasificar)){
							lblConfirmarRegistro.setVisible(true);
							lblConfirmarRegistro.setText("Se registro el parque");	
							txtNombre.setText("");
							txtExtencionKm.setText("");
							txtUbicacion.setText("");
							txtNumeroEspecies.setText("");
							txtTemperatura.setText("");
							txtCapacidadVisitantes.setText("");
							txtCostoIngreso.setText("");;
						}
					}
					else{
						lblConfirmarRegistro.setVisible(true);
						lblConfirmarRegistro.setText("ya lo registro 1 vez no se puede mas");
					}
				} 
				catch (NumberFormatException | EspaciosNegativosOVacios e1) {
					lblConfirmarRegistro.setVisible(true);
					lblConfirmarRegistro.setText("Ingrese los datos nuevamente de manera correcta");
				}
				catch (Exception exception){
					lblConfirmarRegistro.setVisible(true);
					lblConfirmarRegistro.setText("No se ha realizado la acci�n");
				}
			}
		});
		btnRegistrar.setBounds(46, 287, 89, 23);
		frmAreaSinClasificar.getContentPane().add(btnRegistrar);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmAreaSinClasificar.setVisible(false);
			}
		});
		btnCerrar.setBounds(161, 287, 89, 23);
		frmAreaSinClasificar.getContentPane().add(btnCerrar);
		
	}
	public String ObtenerFecha(){

		Calendar fecha = Calendar.getInstance();
		int ano = fecha.get(Calendar.YEAR);
		int mes = fecha.get(Calendar.MONTH);
		int dia = fecha.get(Calendar.DAY_OF_MONTH);
		int hora = fecha.get(Calendar.HOUR);
		int minuto = fecha.get(Calendar.MINUTE);
		int segundo = fecha.get(Calendar.SECOND);
		String txt = ano + "/" + mes + "/" + dia + " " + hora + ":" + minuto + ":" + segundo;
		return txt;
		
	}

}
