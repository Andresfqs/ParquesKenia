package Forms;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import parques.Guardar;
import Menu.FormMenu;

public class FormVisitante {
	private JFrame frmVisitante;
	private JTextField txtNombreGuia;
	private JTextField txtNombreParque;
	
	public void setVisible(boolean visibilidad)
	{
		frmVisitante.setVisible(visibilidad);
	}
	/**
	 * Create the application.
	 */
	public FormVisitante() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmVisitante = new JFrame();
		frmVisitante.setTitle("Visitante");
		frmVisitante.setBounds(100, 100, 450, 300);
		frmVisitante.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmVisitante.getContentPane().setLayout(null);
		
		JLabel lblRegistroDeVisitantes = new JLabel("Registro de visitantes");
		lblRegistroDeVisitantes.setBounds(141, 23, 158, 14);
		frmVisitante.getContentPane().add(lblRegistroDeVisitantes);
		
		JComboBox comboBoxTipoDeParque = new JComboBox();
		comboBoxTipoDeParque.setModel(new DefaultComboBoxModel(new String[] {"Reserva de Caza", "Area acuatica ","Area  terrestre", "Otro tipo"}));
		comboBoxTipoDeParque.setBounds(55, 48, 143, 20);
		frmVisitante.getContentPane().add(comboBoxTipoDeParque);
		
		JLabel lblGuia = new JLabel("Guia");
		lblGuia.setBounds(55, 117, 46, 14);
		frmVisitante.getContentPane().add(lblGuia);
		
		txtNombreGuia = new JTextField();
		txtNombreGuia.setBounds(176, 114, 86, 20);
		frmVisitante.getContentPane().add(txtNombreGuia);
		txtNombreGuia.setColumns(10);
		
		JLabel lblTexto = new JLabel(" ");
		lblTexto.setBounds(55, 155, 329, 68);
		frmVisitante.getContentPane().add(lblTexto);
		lblTexto.setVisible(false);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{	
					if(comboBoxTipoDeParque.getSelectedItem().toString().equals("Reserva de Caza")){
						lblTexto.setVisible(true);
						String nombre = "no";
						for(int i =0;  i<FormMenu.Lista_ReservasCaza.size();  i++){
							if(FormMenu.Lista_ReservasCaza.get(i).nombre_parque.toLowerCase().equals(txtNombreParque.getText().toString().toLowerCase())){
								nombre = FormMenu.Lista_ReservasCaza.get(i).nombre_parque.toString();
							}
						}
						if(nombre != "no"){
							lblTexto.setText("Visitando Reserva  de Caza " + nombre + " con el guia " + txtNombreGuia.getText().toString());
							String texto="visitando Reserva de Caza "+ nombre +" con el guia "+txtNombreGuia.getText().toString()+" "+Guardar.ObtenerFecha();
							Guardar visita=new Guardar(texto);
							visita.Guardar();
							txtNombreGuia.setText("");
							txtNombreParque.setText("");
							
						}
						if(nombre == "no"){
							lblTexto.setText("Valide Que el nombre y el tipo de area sean los correctos");
						}
					}
					else if(comboBoxTipoDeParque.getSelectedItem().toString().equals("Area acuatica ")){
						lblTexto.setVisible(true);
						String nombre = "no";
						for(int i =0;  i<FormMenu.Lista_AreaAcuatica.size();  i++){
							if(FormMenu.Lista_AreaAcuatica.get(i).nombre_parque.toLowerCase().equals(txtNombreParque.getText().toString().toLowerCase())){
								nombre = FormMenu.Lista_AreaAcuatica.get(i).nombre_parque.toString();
							}
						}
						if(nombre != "no"){
							lblTexto.setText("Visitando Area Acuatica " + nombre + " con el guia " + txtNombreGuia.getText().toString());
							String texto="visitando Area Acuatica "+ nombre +" con el guia "+txtNombreGuia.getText().toString()+" "+Guardar.ObtenerFecha();
							Guardar visita=new Guardar(texto);
							visita.Guardar();
							txtNombreGuia.setText("");
							txtNombreParque.setText("");
						}
						if(nombre == "no"){
							lblTexto.setText("Valide Que el nombre y el tipo de area sean los correctos");
						}
						
					}	
					else if(comboBoxTipoDeParque.getSelectedItem().toString().equals("Area  terrestre")){
						lblTexto.setVisible(true);
						String nombre = "no";
						for(int i =0;  i<FormMenu.Lista_AreaTerrestre.size();  i++){
							if(FormMenu.Lista_AreaTerrestre.get(i).nombre_parque.toLowerCase().equals(txtNombreParque.getText().toString().toLowerCase())){
								nombre = FormMenu.Lista_AreaTerrestre.get(i).nombre_parque.toString();
							}
						}
						if(nombre != "no"){
							lblTexto.setText("Visitando Area Terrestre" + nombre + " con el guia " + txtNombreGuia.getText().toString());
							String texto="visitando Area Terrestre"+ nombre +" con el guia  "+txtNombreGuia.getText().toString()+" "+Guardar.ObtenerFecha();
							Guardar visita=new Guardar(texto);
							visita.Guardar();
							txtNombreGuia.setText("");
							txtNombreParque.setText("");
						}
						if(nombre == "no"){
							lblTexto.setText("Valide Que el nombre y el tipo de area sean los correctos");
						}
					}
					else if(comboBoxTipoDeParque.getSelectedItem().toString().equals("Otro tipo")){
						lblTexto.setVisible(true);
						String nombre = "no";
						for(int i =0;  i<FormMenu.Lista_AreaSinClasificar.size();  i++){
							if(FormMenu.Lista_AreaSinClasificar.get(i).nombre_parque.toLowerCase().equals(txtNombreParque.getText().toString().toLowerCase())){
								nombre = FormMenu.Lista_AreaSinClasificar.get(i).nombre_parque.toString();
							}
						}
						if(nombre != "no"){
							lblTexto.setText("Visitando Area " + nombre + " con el guia " + txtNombreGuia.getText().toString());
							String texto="visitando Area "+ nombre +" con el guia  "+txtNombreGuia.getText().toString()+" "+Guardar.ObtenerFecha();
							Guardar visita=new Guardar(texto);
							visita.Guardar();
							txtNombreGuia.setText("");
							txtNombreParque.setText("");
						}
						if(nombre == "no"){
							lblTexto.setText("Valide Que el nombre y el tipo de area sean los correctos");
						}
					}
				}
				catch (IndexOutOfBoundsException ex){
					lblTexto.setVisible(true);
					lblTexto.setText("No se han registrado ningun parque de ese tipo.");
				}
				catch (Exception exception){
					lblTexto.setVisible(true);
					lblTexto.setText("No se logro la acci�n.");
				}
			}
		});
		btnRegistrar.setBounds(313, 113, 89, 23);
		frmVisitante.getContentPane().add(btnRegistrar);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblTexto.setVisible(false);
				lblTexto.setText("");
				frmVisitante.setVisible(false);
			}
		});
		btnCerrar.setBounds(173, 228, 89, 23);
		frmVisitante.getContentPane().add(btnCerrar);
		
		JLabel lblNombreDelParque = new JLabel("Nombre del parque");
		lblNombreDelParque.setBounds(55, 79, 130, 14);
		frmVisitante.getContentPane().add(lblNombreDelParque);
		
		txtNombreParque = new JTextField();
		txtNombreParque.setBounds(176, 79, 86, 20);
		frmVisitante.getContentPane().add(txtNombreParque);
		txtNombreParque.setColumns(10);
	}
}
