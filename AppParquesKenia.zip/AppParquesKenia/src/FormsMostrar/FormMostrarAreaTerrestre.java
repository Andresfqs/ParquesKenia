package FormsMostrar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import Menu.FormMenu;

public class FormMostrarAreaTerrestre {

	private JFrame frmMostrarAreaTerrestre;
	private DefaultTableModel modelo;
	int contador = 0; 
	private JTable table;

	public void setVisible(boolean visibilidad)
	{
		frmMostrarAreaTerrestre.setVisible(visibilidad);
	}
	/**
	 * Create the application.
	 */
	public FormMostrarAreaTerrestre() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMostrarAreaTerrestre = new JFrame();
		frmMostrarAreaTerrestre.setTitle("Area terrestre");
		frmMostrarAreaTerrestre.setBounds(100, 100, 569, 349);
		frmMostrarAreaTerrestre.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmMostrarAreaTerrestre.getContentPane().setLayout(null);
		
		JLabel lblAreasTerrestres = new JLabel("Areas Terrestres");
		lblAreasTerrestres.setHorizontalAlignment(SwingConstants.CENTER);
		lblAreasTerrestres.setBounds(202, 15, 163, 14);
		frmMostrarAreaTerrestre.getContentPane().add(lblAreasTerrestres);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMostrarAreaTerrestre.setVisible(false);
			}
		});
		btnCerrar.setBounds(148, 279, 89, 23);
		frmMostrarAreaTerrestre.getContentPane().add(btnCerrar);
		
		Object [][] modelo1 = new Object[FormMenu.Lista_AreaTerrestre.size()][9];
		String columnas[] = {"Nombre", "Extencion", "Ubicacion", "Especies", "Temperatura", "Capacidad", "Donacion", "ONG", "Terreno"}; 
		modelo = new DefaultTableModel(modelo1, columnas);
		table = new JTable();
		table.setModel(modelo);
		table.setBounds(52, 55, 455, 194);
		frmMostrarAreaTerrestre.getContentPane().add(table);
		
		JButton btnMostar = new JButton("Mostar");
		btnMostar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				for(int i=0; i<FormMenu.Lista_AreaTerrestre.size(); i++){
					modelo.insertRow(contador, new Object[]{});
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).nombre_parque.toString(), contador, 0);
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).extencion_km2, contador, 1);
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).ubicacion, contador, 2);
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).numero_especies, contador, 3);
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).temperatura_gradosc, contador, 4);
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).capacidad_visitantes, contador, 5);
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).donacion_govierno, contador, 6);
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).nombre_ONG, contador, 7);
					modelo.setValueAt(FormMenu.Lista_AreaTerrestre.get(i).Tipo_terreno.toString(), contador, 8);
					contador++;
				}
			}
		});
		btnMostar.setBounds(298, 279, 89, 23);
		frmMostrarAreaTerrestre.getContentPane().add(btnMostar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(52, 55, 455, 194);
		frmMostrarAreaTerrestre.getContentPane().add(scrollPane);
		scrollPane.setViewportView(table);
	}

}
