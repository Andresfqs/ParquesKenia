package FormsMostrar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import Menu.FormMenu;

public class FormMostrarAreaSinClasificar {

	private JFrame frmMostrarAreaSinClasificar;
	private DefaultTableModel modelo;
	int contador = 0; 
	private JTable table;

	public void setVisible(boolean visibilidad)
	{
		frmMostrarAreaSinClasificar.setVisible(visibilidad);
	}
	/**
	 * Create the application.
	 */
	public FormMostrarAreaSinClasificar() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMostrarAreaSinClasificar = new JFrame();
		frmMostrarAreaSinClasificar.setTitle("Area sin clasificar");
		frmMostrarAreaSinClasificar.setBounds(100, 100, 601, 369);
		frmMostrarAreaSinClasificar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmMostrarAreaSinClasificar.getContentPane().setLayout(null);
		
		JLabel lblOtrasAreas = new JLabel("Otras Areas");
		lblOtrasAreas.setHorizontalAlignment(SwingConstants.CENTER);
		lblOtrasAreas.setBounds(217, 27, 131, 14);
		frmMostrarAreaSinClasificar.getContentPane().add(lblOtrasAreas);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMostrarAreaSinClasificar.setVisible(false);
			}
		});
		btnCerrar.setBounds(183, 287, 89, 23);
		frmMostrarAreaSinClasificar.getContentPane().add(btnCerrar);
		
		Object [][] modelo1 = new Object[FormMenu.Lista_AreaSinClasificar.size()][7];
		String columnas[] = {"Nombre", "Extencion", "Ubicacion", "Especies", "Temperatura", "Capacidad", "Costo Ingreso"}; 
		modelo = new DefaultTableModel(modelo1, columnas);
		table = new JTable();
		table.setModel(modelo);
		table.setBounds(52, 55, 455, 194);
		frmMostrarAreaSinClasificar.getContentPane().add(table);
		
		JButton btnMostar = new JButton("Mostar");
		btnMostar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				for(int i=0; i<FormMenu.Lista_AreaSinClasificar.size(); i++){
					modelo.insertRow(contador, new Object[]{});
					modelo.setValueAt(FormMenu.Lista_AreaSinClasificar.get(i).nombre_parque.toString(), contador, 0);
					modelo.setValueAt(FormMenu.Lista_AreaSinClasificar.get(i).extencion_km2, contador, 1);
					modelo.setValueAt(FormMenu.Lista_AreaSinClasificar.get(i).ubicacion.toString(), contador, 2);
					modelo.setValueAt(FormMenu.Lista_AreaSinClasificar.get(i).numero_especies, contador, 3);
					modelo.setValueAt(FormMenu.Lista_AreaSinClasificar.get(i).temperatura_gradosc, contador, 4);
					modelo.setValueAt(FormMenu.Lista_AreaSinClasificar.get(i).capacidad_visitantes, contador, 5);
					modelo.setValueAt(FormMenu.Lista_AreaSinClasificar.get(i).costo_ingreso, contador, 6);
					contador++;
				}
			}
		});
		btnMostar.setBounds(311, 287, 89, 23);
		frmMostrarAreaSinClasificar.getContentPane().add(btnMostar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(52, 55, 455, 194);
		frmMostrarAreaSinClasificar.getContentPane().add(scrollPane);
		scrollPane.setViewportView(table);
	}

}

