package FormsMostrar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import Menu.FormMenu;

public class FormMostrarReservasCaza {

	private JFrame frmMostrarReservasCaza;
	private DefaultTableModel modelo;
	int contador = 0; 
	private JTable table;

	public void setVisible(boolean visibilidad)
	{
		frmMostrarReservasCaza.setVisible(visibilidad);
	}
	/**
	 * Create the application.
	 */
	public FormMostrarReservasCaza() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMostrarReservasCaza = new JFrame();
		frmMostrarReservasCaza.setTitle("Reservas de caza");
		frmMostrarReservasCaza.setBounds(100, 100, 598, 399);
		frmMostrarReservasCaza.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmMostrarReservasCaza.getContentPane().setLayout(null);
		
		JLabel lblReservasDeCaza = new JLabel("Reservas de caza");
		lblReservasDeCaza.setHorizontalAlignment(SwingConstants.CENTER);
		lblReservasDeCaza.setBounds(218, 23, 116, 14);
		frmMostrarReservasCaza.getContentPane().add(lblReservasDeCaza);
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMostrarReservasCaza.setVisible(false);
			}
		});
		btnCerrar.setBounds(168, 310, 89, 23);
		frmMostrarReservasCaza.getContentPane().add(btnCerrar);
		
		Object [][] modelo1 = new Object[FormMenu.Lista_ReservasCaza.size()][8];
		String columnas[] = {"Nombre", "Extencion", "Ubicacion", "Especies", "Temperatura", "Capacidad", "Costo ingreso", "Arma"}; 
		modelo = new DefaultTableModel(modelo1, columnas);
		table = new JTable();
		table.setModel(modelo);
		table.setBounds(52, 55, 455, 194);
		frmMostrarReservasCaza.getContentPane().add(table);
		
		JButton btnMostar = new JButton("Mostar");
		btnMostar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				for(int i=0; i<FormMenu.Lista_ReservasCaza.size(); i++){
					modelo.insertRow(contador, new Object[]{});
					modelo.setValueAt(FormMenu.Lista_ReservasCaza.get(i).nombre_parque.toString(), contador, 0);
					modelo.setValueAt(FormMenu.Lista_ReservasCaza.get(i).extencion_km2, contador, 1);
					modelo.setValueAt(FormMenu.Lista_ReservasCaza.get(i).ubicacion, contador, 2);
					modelo.setValueAt(FormMenu.Lista_ReservasCaza.get(i).numero_especies, contador, 3);
					modelo.setValueAt(FormMenu.Lista_ReservasCaza.get(i).temperatura_gradosc, contador, 4);
					modelo.setValueAt(FormMenu.Lista_ReservasCaza.get(i).capacidad_visitantes, contador, 5);
					modelo.setValueAt(FormMenu.Lista_ReservasCaza.get(i).costo_ingreso, contador, 6);
					modelo.setValueAt(FormMenu.Lista_ReservasCaza.get(i).arma.toString(), contador, 7);
					contador++;
				}
			}
		});
		btnMostar.setBounds(312, 310, 89, 23);
		frmMostrarReservasCaza.getContentPane().add(btnMostar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(52, 55, 455, 194);
		frmMostrarReservasCaza.getContentPane().add(scrollPane);
		scrollPane.setViewportView(table);
	}
}