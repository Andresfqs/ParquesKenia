package parques;

import java.util.Calendar;

import Excepciones.*;

public class Parque implements Visitable{
	public String nombre_parque;
	public double extencion_km2;
	public String ubicacion;
	public int numero_especies;
	public double temperatura_gradosc;
	public int capacidad_visitantes;
	public String fecha_creacion = ObtenerFecha();  
	public static String ruta_archivo="\\datos\\parques.txt";
	public String getNombre_parque() {
		return nombre_parque;
	}
	public void setNombre_parque(String nombre_parque) {
		this.nombre_parque = nombre_parque;
	}
	public double getTemperatura_gradosc() {
		return temperatura_gradosc;
	}
	public void setTemperatura_gradosc(double temperatura_gradosc) {
		this.temperatura_gradosc = temperatura_gradosc;
	}
	public double getExtencion_km2() {
		return extencion_km2;
	}
	public String getUbicacion() {
		return ubicacion;
	}
	public int getNumero_especies() {
		return numero_especies;
	}
	public int getCapacidad_visitantes() {
		return capacidad_visitantes;
	}
	public String getFecha_creacion() {
		return fecha_creacion;
	}
	public String ObtenerFecha(){

		Calendar fecha = Calendar.getInstance();
		int ano = fecha.get(Calendar.YEAR);
		int mes = fecha.get(Calendar.MONTH);
		int dia = fecha.get(Calendar.DAY_OF_MONTH);
		int hora = fecha.get(Calendar.HOUR);
		int minuto = fecha.get(Calendar.MINUTE);
		int segundo = fecha.get(Calendar.SECOND);
		String txt = ano + "/" + mes + "/" + dia + " " + hora + ":" + minuto + ":" + segundo;
		return txt;
		
	}
	public String Visitar(String nombre_guia, int i)throws VisitarExcepcion
	{
		if (i==-1)
		{
			throw new VisitarExcepcion();
		}
		else
		{
			String texto="visitando area- "+this.nombre_parque+"con el guia- "+nombre_guia;
			return texto;
		}
	}
}