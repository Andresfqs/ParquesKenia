package parques;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Excepciones.EspaciosNegativosOVacios;
public class AreaTerrestre extends AreaProtegida{
	public String Tipo_terreno;
	public String getTipo_terreno() {
		return Tipo_terreno;
	}
	public AreaTerrestre(String nombre_parque, double extencion_km2, String ubicacion, int numero_especies, double temperatura_gradosc,int capacidad_visitantes, double donacion_govierno, String nombre_ONG, String Tipo_terreno, String fecha_creacion) throws EspaciosNegativosOVacios
	{
		if (nombre_parque==null||extencion_km2==0||ubicacion==null||numero_especies==0||temperatura_gradosc==0||capacidad_visitantes==0||donacion_govierno==0||nombre_ONG==null ||Tipo_terreno==null||fecha_creacion==null)	
		{
			throw new EspaciosNegativosOVacios();
		}
		else
		{
			this.nombre_parque=nombre_parque;
			this.extencion_km2=extencion_km2;
			this.ubicacion=ubicacion;
			this.numero_especies=numero_especies;
			this.temperatura_gradosc=temperatura_gradosc;
			this.capacidad_visitantes=capacidad_visitantes;
			this.donacion_govierno=donacion_govierno;
			this.nombre_ONG=nombre_ONG;
			this.Tipo_terreno=Tipo_terreno;
			this.fecha_creacion=fecha_creacion;
		}
	}
	public static int BuscarAreaTerrestre(String nombre_parque,  ArrayList<AreaTerrestre>lista_AreasTerrestres)
	{
		for (int i=0; i<lista_AreasTerrestres.size(); i++)
		{
			if (nombre_parque.equals(lista_AreasTerrestres.get(i).nombre_parque))
			{
				return i;
			}
		}
		return -1;
	}
	public static String ImprimirAreasTerrestres(ArrayList<AreaTerrestre>lista_AreasTerrestres)
    {
	 String datos="Reservas de caza:";
    	for(int i=0; i<lista_AreasTerrestres.size(); i++){
    	datos=datos+"\n";
    	datos = datos+"Nombre: "+lista_AreasTerrestres.get(i).nombre_parque+"- Extencion en kilometros cuadrados: "+lista_AreasTerrestres.get(i).extencion_km2+"-Ubicasion: "+lista_AreasTerrestres.get(i).ubicacion+"-Numero de especies: "+lista_AreasTerrestres.get(i).numero_especies+"-Temperatura en grados centigrados: "+lista_AreasTerrestres.get(i).temperatura_gradosc+"-Capacidad de visitantes: "+lista_AreasTerrestres.get(i).capacidad_visitantes+"-Donasion del govierno: "+lista_AreasTerrestres.get(i).donacion_govierno+"-Nombre de la ONG: "+lista_AreasTerrestres.get(i).nombre_ONG+"-Tipo de terreno : "+lista_AreasTerrestres.get(i).Tipo_terreno+"-Fecha de creacion: "+lista_AreasTerrestres.get(i).fecha_creacion;
    	}
    	return datos;
    }
	public String ConvertirObjeto()
	{
		return "AreaTerrestre"+";"+this.nombre_parque+";"+this.extencion_km2+";"+this.ubicacion+";"+this.numero_especies+";"+this.temperatura_gradosc+";"+this.capacidad_visitantes+";"+this.donacion_govierno+";"+this.nombre_ONG+";"+this.Tipo_terreno+";"+this.fecha_creacion;
	}
	public static AreaTerrestre ConvertirArchivo(String linea_archivo)
	{
	
			String [] datos=linea_archivo.split(";");
			if (datos[0].equals("AreaTerrestre")){
				double extencion_km2=Double.parseDouble(datos[2]);
				int numero_especies=Integer.parseInt(datos[4]);
				double temperatura_gradosc=Double.parseDouble(datos[5]);
				int capacidad_visitantes=Integer.parseInt(datos[6]);
				double donacion_govierno=Double.parseDouble(datos[7]);
				AreaTerrestre areaterrestre;
						try {
							areaterrestre = new AreaTerrestre(datos[1],extencion_km2,datos[3],numero_especies,temperatura_gradosc,capacidad_visitantes,donacion_govierno,datos[8],datos[9],datos[10]);
							return areaterrestre;
						} catch (EspaciosNegativosOVacios e) {
							e.printStackTrace();
						}
			}
			return null;
	}
	public boolean Guardar()
	{
		String ruta_archivo=System.getProperty("user.dir")+"\\datos\\parques.txt";
		
		File archivo =new File(ruta_archivo);
		FileWriter escribir_archivo=null;
		boolean almacenado=false;
		try{
			
				escribir_archivo=new FileWriter(archivo,true);
			
				PrintWriter escritor=new PrintWriter(escribir_archivo);
			
				escritor.println(this.ConvertirObjeto());
				
				escribir_archivo.close();
				almacenado= true;
			}
		catch (IOException e) {
			e.printStackTrace();
		}
		finally 
		{
			try {
				if (escribir_archivo!= null)
				escribir_archivo.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return almacenado;
	}
	public static ArrayList<AreaTerrestre> Leer()
	{
		ArrayList<AreaTerrestre> AreasTerrestres =new ArrayList<AreaTerrestre>();
		String ruta_archivox=System.getProperty("user.dir")+ruta_archivo;
		File archivo=new File( ruta_archivox);
		Scanner lector_archivo=null;
		try {
			FileReader leer= new FileReader(archivo);
			lector_archivo=new Scanner(archivo);
			lector_archivo.hasNextLine();
			while(lector_archivo.hasNextLine())
			{   
				String registro_archivo=lector_archivo.nextLine();
					if((ConvertirArchivo(registro_archivo)==null))
					{
						 registro_archivo=registro_archivo;
					}
					else
					{
						AreaTerrestre areatmp=(ConvertirArchivo(registro_archivo));
						int validar=AreaTerrestre.BuscarAreaTerrestre(areatmp.nombre_parque, AreasTerrestres);
							if (validar==-1)
							{
								AreasTerrestres.add(areatmp);
							}
					}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
			if(lector_archivo!=null)
			{
				lector_archivo.close();
			}
		}
		return AreasTerrestres;
	}
}