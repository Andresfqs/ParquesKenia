package parques;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Excepciones.EspaciosNegativosOVacios;
public class AreaAcuatica extends AreaProtegida{
	public int numero_lagos;
	public int getNumero_lagos() {
		return numero_lagos;
	}
	public AreaAcuatica(String nombre_parque, double extencion_km2, String ubicacion, int numero_especies, double temperatura_gradosc,int capacidad_visitantes, double donacion_govierno, String nombre_ONG, int numero_lagos, String fecha_creacion) throws EspaciosNegativosOVacios
	{ 
		if (nombre_parque==null||extencion_km2==0||ubicacion==null||numero_especies==0||temperatura_gradosc==0||capacidad_visitantes==0||donacion_govierno==0||nombre_ONG==null||fecha_creacion==null)	
		{
			throw new EspaciosNegativosOVacios();
		}
		else
		{
			this.nombre_parque=nombre_parque;
			this.extencion_km2=extencion_km2;
			this.ubicacion=ubicacion;
			this.numero_especies=numero_especies;
			this.temperatura_gradosc=temperatura_gradosc;
			this.capacidad_visitantes=capacidad_visitantes;
			this.donacion_govierno=donacion_govierno;
			this.nombre_ONG=nombre_ONG;
			this.numero_lagos=numero_lagos;
			this.fecha_creacion=fecha_creacion;
		}
	}
	public static  int BuscarAreaAcuatica(String nombre_parque,  ArrayList<AreaAcuatica>lista_AreasAcuaticas)
	{
		for (int i=0; i<lista_AreasAcuaticas.size(); i++)
		{
			if (nombre_parque.equals(lista_AreasAcuaticas.get(i).nombre_parque))
			{
				return i;
			}
		}
		return -1;
	}
	public static String ImprimirAreasAcuaticas(ArrayList<AreaAcuatica>lista_AreasAcuaticas)
    {
	 String datos="Reservas de caza:";
    	for(int i=0; i<lista_AreasAcuaticas.size(); i++){
    	datos=datos+"\n";
    	datos = datos+"Nombre: "+lista_AreasAcuaticas.get(i).nombre_parque+"- Extencion en kilometros cuadrados: "+lista_AreasAcuaticas.get(i).extencion_km2+"-Ubicasion: "+lista_AreasAcuaticas.get(i).ubicacion+"-Numero de especies: "+lista_AreasAcuaticas.get(i).numero_especies+"-Temperatura en grados centigrados: "+lista_AreasAcuaticas.get(i).temperatura_gradosc+"-Capacidad de visitantes: "+lista_AreasAcuaticas.get(i).capacidad_visitantes+"-Donasion del govierno: "+lista_AreasAcuaticas.get(i).donacion_govierno+"-Nombre de la ONG: "+lista_AreasAcuaticas.get(i).nombre_ONG+"-Numero de lagos: "+lista_AreasAcuaticas.get(i).numero_lagos+"-Fecha de creacion: "+lista_AreasAcuaticas.get(i).fecha_creacion;
    	}
    	return datos;
    }
	public String ConvertirObjeto()
	{
		return "AreaAcuatica"+";"+this.nombre_parque+";"+this.extencion_km2+";"+this.ubicacion+";"+this.numero_especies+";"+this.temperatura_gradosc+";"+this.capacidad_visitantes+";"+this.donacion_govierno+";"+this.nombre_ONG+";"+this.numero_lagos+";"+this.fecha_creacion;
	}
	public static AreaAcuatica ConvertirArchivo(String linea_archivo)
	{
	
			String [] datos=linea_archivo.split(";");
				if (datos[0].equals("AreaAcuatica"))
				{
					double extencion_km2=Double.parseDouble(datos[2]);
					int numero_especies=Integer.parseInt(datos[4]);
					double temperatura_gradosc=Double.parseDouble(datos[5]);
					int capacidad_visitantes=Integer.parseInt(datos[6]);
					double donacion_govierno=Double.parseDouble(datos[7]);
					int numero_lagos=Integer.parseInt(datos[9]);
					AreaAcuatica areaacuatica;
				
						 try {
							areaacuatica = new AreaAcuatica(datos[1],extencion_km2,datos[3],numero_especies,temperatura_gradosc,capacidad_visitantes,donacion_govierno,datos[8],numero_lagos,datos[10]);
				            return areaacuatica;
						 } catch (EspaciosNegativosOVacios e) {
							e.printStackTrace();
						}
				}
			return null;
	}
	public boolean Guardar()
	{
		String ruta_archivo=System.getProperty("user.dir")+"\\datos\\parques.txt";
		
		File archivo =new File(ruta_archivo);
		FileWriter escribir_archivo=null;
		boolean almacenado=false;
		try{
			
				escribir_archivo=new FileWriter(archivo,true);
			
				PrintWriter escritor=new PrintWriter(escribir_archivo);
			
				escritor.println(this.ConvertirObjeto());
				
				escribir_archivo.close();
				almacenado= true;
			}
		catch (IOException e) {
			e.printStackTrace();
		}
		finally 
		{
			try {
				if (escribir_archivo!= null)
				escribir_archivo.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return almacenado;
	}
	public static ArrayList<AreaAcuatica> Leer()
	{
		ArrayList<AreaAcuatica> AreasAcuaticas =new ArrayList<AreaAcuatica>();
		String ruta_archivox=System.getProperty("user.dir")+ruta_archivo;
		File archivo=new File( ruta_archivox);
		Scanner lector_archivo=null;
		try {
			FileReader leer= new FileReader(archivo);
			lector_archivo=new Scanner(archivo);
			lector_archivo.hasNextLine();
			while(lector_archivo.hasNextLine())
			{   
				String registro_archivo=lector_archivo.nextLine();
				
				if(ConvertirArchivo(registro_archivo)==null)
				{
					registro_archivo=registro_archivo;
				}
				else
				{
					AreaAcuatica areatmp=(ConvertirArchivo(registro_archivo));
					int validar=AreaAcuatica.BuscarAreaAcuatica(areatmp.nombre_parque, AreasAcuaticas);
					if (validar==-1)
					{
					AreasAcuaticas.add(areatmp);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
			if(lector_archivo!=null)
			{
				lector_archivo.close();
			}
		}
		return AreasAcuaticas;
	}
}