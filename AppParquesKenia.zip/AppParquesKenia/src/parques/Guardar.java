package parques;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

public class Guardar {
	public String texto;
	public Guardar (String texto)
	{
		this.texto=texto;
	}
	public String ComvertirObjeto()
	{
		return this.texto;
	}
	public boolean Guardar()
	{
		String ruta_archivo=System.getProperty("user.dir")+"\\datos\\visitados.txt";
		
		File archivo =new File(ruta_archivo);
		FileWriter escribir_archivo=null;
		boolean almacenado=false;
		try{
			
				escribir_archivo=new FileWriter(archivo,true);
			
				PrintWriter escritor=new PrintWriter(escribir_archivo);
			
				escritor.println(this.ComvertirObjeto());
				
				escribir_archivo.close();
				almacenado= true;
			}
		catch (IOException e) {
			e.printStackTrace();
		}
		finally 
		{
			try {
				if (escribir_archivo!= null)
				escribir_archivo.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return almacenado;
	}
	public static String ObtenerFecha(){

		Calendar fecha = Calendar.getInstance();
		int ano = fecha.get(Calendar.YEAR);
		int mes = fecha.get(Calendar.MONTH);
		int dia = fecha.get(Calendar.DAY_OF_MONTH);
		int hora = fecha.get(Calendar.HOUR);
		int minuto = fecha.get(Calendar.MINUTE);
		int segundo = fecha.get(Calendar.SECOND);
		String txt = ano + "/" + mes + "/" + dia + " " + hora + ":" + minuto + ":" + segundo;
		return txt;
		
	}
}
