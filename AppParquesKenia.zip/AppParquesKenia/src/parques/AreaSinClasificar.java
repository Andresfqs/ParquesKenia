package parques;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Excepciones.*;
public class AreaSinClasificar extends Parque{
	public double costo_ingreso;
	public double getCosto_ingreso() {
		return costo_ingreso;
	}
	public void setCosto_ingreso(double costo_ingreso) {
		this.costo_ingreso = costo_ingreso;
	}
	public AreaSinClasificar(String nombre_parque, double extencion_km2, String ubicacion, int numero_especies, double temperatura_gradosc,int capacidad_visitantes, double costo_ingreso, String fecha_creacion) throws EspaciosNegativosOVacios
	{
		if (nombre_parque==null||extencion_km2==0||ubicacion==null||numero_especies==0||temperatura_gradosc==0||capacidad_visitantes==0||costo_ingreso==0||fecha_creacion==null)	
		{
			throw new EspaciosNegativosOVacios();
		}
		else{
			this.nombre_parque=nombre_parque;
			this.extencion_km2=extencion_km2;
			this.ubicacion=ubicacion;
			this.numero_especies=numero_especies;
			this.temperatura_gradosc=temperatura_gradosc;
			this.capacidad_visitantes=capacidad_visitantes;
			this.costo_ingreso=costo_ingreso;
			this.fecha_creacion=fecha_creacion;
		}
	}
	public static int BuscarAreaSinClasificar(String nombre_parque,  ArrayList<AreaSinClasificar>lista_AreasSinClasificar)
	{
		for (int i=0; i<lista_AreasSinClasificar.size(); i++)
		{
			if (nombre_parque.equals(lista_AreasSinClasificar.get(i).nombre_parque))
			{
				return i;
			}
		}
		return -1;
	}
	 public static String ImprimirAreasSinClasificar(ArrayList<AreaSinClasificar>lista_AreasSinClasificar)
	    {
		 String datos="Reservas de caza:";
	    	for(int i=0; i<lista_AreasSinClasificar.size(); i++){
	    	datos=datos+"\n";
	    	datos = datos+"Nombre: "+lista_AreasSinClasificar.get(i).nombre_parque+"- Extencion en kilometros cuadrados: "+lista_AreasSinClasificar.get(i).extencion_km2+"-Ubicasion: "+lista_AreasSinClasificar.get(i).ubicacion+"-Numero de especies: "+lista_AreasSinClasificar.get(i).numero_especies+"-Temperatura en grados centigrados: "+lista_AreasSinClasificar.get(i).temperatura_gradosc+"-Capacidad de visitantes: "+lista_AreasSinClasificar.get(i).capacidad_visitantes+"-Costo del ingreso: "+lista_AreasSinClasificar.get(i).costo_ingreso+"-Fecha de creacion: "+lista_AreasSinClasificar.get(i).fecha_creacion;
	    	}
	    	return datos;
	    }
	 public String ConvertirObjeto()
		{
			return "AreaSinClasificar"+";"+this.nombre_parque+";"+this.extencion_km2+";"+this.ubicacion+";"+this.numero_especies+";"+this.temperatura_gradosc+";"+this.capacidad_visitantes+";"+this.costo_ingreso+";"+this.fecha_creacion;
		}
		public static AreaSinClasificar ConvertirArchivo(String linea_archivo)
		{
		
				String [] datos=linea_archivo.split(";");
				if(datos[0].equals("AreaSinClasificar"))
				{
					double extencion_km2=Double.parseDouble(datos[2]);
					int numero_especies=Integer.parseInt(datos[4]);
					double temperatura_gradosc=Double.parseDouble(datos[5]);
					int capacidad_visitantes=Integer.parseInt(datos[6]);
					double costo_ingreso=Double.parseDouble(datos[7]);
					AreaSinClasificar areasinclasificar;
							try {
								areasinclasificar = new AreaSinClasificar(datos[1],extencion_km2,datos[3],numero_especies,temperatura_gradosc,capacidad_visitantes,costo_ingreso,datos[8]);
								return areasinclasificar;
							} catch (EspaciosNegativosOVacios e) {
								e.printStackTrace();
							}
				}
				return null;
		}
		public boolean Guardar()
		{
			String ruta_archivo=System.getProperty("user.dir")+"\\datos\\parques.txt";
			
			File archivo =new File(ruta_archivo);
			FileWriter escribir_archivo=null;
			boolean almacenado=false;
			try{
				
					escribir_archivo=new FileWriter(archivo,true);
				
					PrintWriter escritor=new PrintWriter(escribir_archivo);
				
					escritor.println(this.ConvertirObjeto());
					
					escribir_archivo.close();
					almacenado= true;
				}
			catch (IOException e) {
				e.printStackTrace();
			}
			finally 
			{
				try {
					if (escribir_archivo!= null)
					escribir_archivo.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return almacenado;
		}
		public static ArrayList<AreaSinClasificar> Leer()
		{
			ArrayList<AreaSinClasificar> AreasSinClasificar =new ArrayList<AreaSinClasificar>();
			String ruta_archivox=System.getProperty("user.dir")+ruta_archivo;
			File archivo=new File( ruta_archivox);
			Scanner lector_archivo=null;
			try {
				FileReader leer= new FileReader(archivo);
				lector_archivo=new Scanner(archivo);
				lector_archivo.hasNextLine();
				while(lector_archivo.hasNextLine())
				{
					String registro_archivo=lector_archivo.nextLine();
					if(ConvertirArchivo(registro_archivo)==null)
					{
						registro_archivo=registro_archivo;
					}
						else{
							AreaSinClasificar areatmp=(ConvertirArchivo(registro_archivo));
								int validar=AreaSinClasificar.BuscarAreaSinClasificar(areatmp.nombre_parque, AreasSinClasificar);
								if (validar==-1)
								{
									AreasSinClasificar.add(areatmp);
								}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				if(lector_archivo!=null)
				{
					lector_archivo.close();
				}
			}
			return AreasSinClasificar;
		}
}