package parques;
import Excepciones.VisitarExcepcion;
public interface Visitable {
	public String Visitar(String nombre_guia, int i) throws VisitarExcepcion;
}