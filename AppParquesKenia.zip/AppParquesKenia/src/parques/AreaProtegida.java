package parques;
public class AreaProtegida extends Parque{
	public double donacion_govierno;
	public String nombre_ONG;
	public double getDonacion_govierno() {
		return donacion_govierno;
	}
	public String getNombre_ONG() {
		return nombre_ONG;
	}
	
}