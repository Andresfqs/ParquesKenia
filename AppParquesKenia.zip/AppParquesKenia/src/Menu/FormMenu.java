package Menu;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import Forms.FormAreaAcuatica;
import Forms.FormAreaSinClasificar;
import Forms.FormAreaTerrestre;
import Forms.FormReservaCaza;
import Forms.FormVisitante;
import parques.AreaAcuatica;
import parques.AreaSinClasificar;
import parques.AreaTerrestre;
import parques.ReservaCaza;
import FormsMostrar.FormMostrarAreaAcuatica;
import FormsMostrar.FormMostrarAreaSinClasificar;
import FormsMostrar.FormMostrarAreaTerrestre;
import FormsMostrar.FormMostrarReservasCaza;
import java.awt.Font;

public class FormMenu {

	private FormReservaCaza formularioReservaCaza = new FormReservaCaza();
	private FormAreaAcuatica formularioAreaAcuatica = new FormAreaAcuatica();
	private FormAreaTerrestre formularioAreaTerrestre = new FormAreaTerrestre();
	private FormAreaSinClasificar formilarioAreaSinCLasificar = new FormAreaSinClasificar();
	private FormVisitante formularioVisitante = new FormVisitante();
	private FormMostrarAreaAcuatica formulariomostrarareaAcuatica = new FormMostrarAreaAcuatica();
	private FormMostrarAreaSinClasificar formulariomostrarareasinclasificar = new FormMostrarAreaSinClasificar();
	private FormMostrarAreaTerrestre formulatioMostrarAreaTerrestre = new FormMostrarAreaTerrestre();
	private FormMostrarReservasCaza formulariomostrarReservacaza = new FormMostrarReservasCaza();
	private JFrame frmParquesKenia;
	private JComboBox comboBoxMostrar;
	private JComboBox comboBoxRegistrar;
	private JButton btnNewButton_1;
	private JButton btnNewButton;
	private JLabel lblConsultar;
	private JLabel lblRegistrar;
	public static ArrayList<ReservaCaza> Lista_ReservasCaza= new ArrayList<ReservaCaza>();
	public static ArrayList<AreaAcuatica> Lista_AreaAcuatica= new ArrayList<AreaAcuatica>();
	public static ArrayList<AreaTerrestre> Lista_AreaTerrestre= new ArrayList<AreaTerrestre>();
	public static ArrayList<AreaSinClasificar> Lista_AreaSinClasificar= new ArrayList<AreaSinClasificar>();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FormMenu window = new FormMenu();
					window.frmParquesKenia.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FormMenu() {
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		Lista_ReservasCaza.addAll(ReservaCaza.Leer());
		Lista_AreaAcuatica.addAll(AreaAcuatica.Leer());
		Lista_AreaTerrestre.addAll(AreaTerrestre.Leer());
		Lista_AreaSinClasificar.addAll(AreaSinClasificar.Leer());
		 
		frmParquesKenia = new JFrame();
		frmParquesKenia.setTitle("Parques kenia");
		frmParquesKenia.setBounds(100, 100, 456, 300);
		frmParquesKenia.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmParquesKenia.getContentPane().setLayout(null);
		
		lblRegistrar = new JLabel("Registrar");
		lblRegistrar.setBounds(35, 68, 74, 14);
		frmParquesKenia.getContentPane().add(lblRegistrar);
		
		lblConsultar = new JLabel("Consultar");
		lblConsultar.setBounds(35, 134, 74, 14);
		frmParquesKenia.getContentPane().add(lblConsultar);
		
		comboBoxRegistrar = new JComboBox();
		comboBoxRegistrar.setModel(new DefaultComboBoxModel(new String[] {"Reserva de caza", "\u00C1rea de reserva acuatica", "\u00C1rea de reserva terrestre", "Visitante", "Otro"}));
		comboBoxRegistrar.setBounds(103, 65, 163, 20);
		frmParquesKenia.getContentPane().add(comboBoxRegistrar);
		
		comboBoxMostrar = new JComboBox();
		comboBoxMostrar.setModel(new DefaultComboBoxModel(new String[] {"Reservas de caza", "\u00C1reas acuaticas", "\u00C1reas terrestres", "\u00C1reas sin clasificar"}));
		comboBoxMostrar.setBounds(103, 131, 163, 20);
		frmParquesKenia.getContentPane().add(comboBoxMostrar);
		
		btnNewButton = new JButton("Registrar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxRegistrar.getSelectedItem().toString().equals("Reserva de caza")){
					formularioReservaCaza.setVisible(true);
				}
				else if(comboBoxRegistrar.getSelectedItem().toString().equals("\u00C1rea de reserva acuatica")){
					formularioAreaAcuatica.setVisible(true);
				}
				else if(comboBoxRegistrar.getSelectedItem().toString().equals("\u00C1rea de reserva terrestre")){
					formularioAreaTerrestre.setVisible(true);
				}
				else if(comboBoxRegistrar.getSelectedItem().toString().equals("Visitante")){
					formularioVisitante.setVisible(true);
				}
				else if(comboBoxRegistrar.getSelectedItem().toString().equals("Otro")){
					formilarioAreaSinCLasificar.setVisible(true);
				}

			}
		});
		btnNewButton.setBounds(317, 64, 89, 23);
		frmParquesKenia.getContentPane().add(btnNewButton);
		
		btnNewButton_1 = new JButton("Mostrar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxMostrar.getSelectedItem().toString().equals("Reservas de caza")){
					formulariomostrarReservacaza.setVisible(true);
				}
				else if(comboBoxMostrar.getSelectedItem().toString().equals("\u00C1reas acuaticas")){
					formulariomostrarareaAcuatica.setVisible(true);
				}
				else if(comboBoxMostrar.getSelectedItem().toString().equals("\u00C1reas terrestres")){
					formulatioMostrarAreaTerrestre.setVisible(true);
				}
				else if(comboBoxMostrar.getSelectedItem().toString().equals("\u00C1reas sin clasificar")){
					formulariomostrarareasinclasificar.setVisible(true);
				}
			}
		});
		btnNewButton_1.setBounds(317, 130, 89, 23);
		frmParquesKenia.getContentPane().add(btnNewButton_1);
		
		JLabel lblParquesKenia = new JLabel("Parques Kenia");
		lblParquesKenia.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblParquesKenia.setBounds(149, 22, 144, 32);
		frmParquesKenia.getContentPane().add(lblParquesKenia);
		
		JMenuBar menuBar = new JMenuBar();
		frmParquesKenia.setJMenuBar(menuBar);
		
		JMenu mnRegistrar = new JMenu("Registrar");
		menuBar.add(mnRegistrar);
		
		JMenu mnAreas = new JMenu("Registro de \u00E1reas protegidas");
		mnRegistrar.add(mnAreas);
		
		JMenuItem mntmRegistroAreasAcuaticas = new JMenuItem("Registro de \u00E1rea acuatica");
		mntmRegistroAreasAcuaticas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				formularioAreaAcuatica.setVisible(true);
			}
		});
		mnAreas.add(mntmRegistroAreasAcuaticas);
		
		JMenuItem mntmRegistroAreasTerrestres = new JMenuItem("Registro de \u00E1rea terrestre");
		mntmRegistroAreasTerrestres.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formularioAreaTerrestre.setVisible(true);
			}
		});
		mnAreas.add(mntmRegistroAreasTerrestres);
		
		JMenuItem mntmRegistroDeReservas = new JMenuItem("Registro de reserva de caza");
		mntmRegistroDeReservas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formularioReservaCaza.setVisible(true);
			}
		});
		mnRegistrar.add(mntmRegistroDeReservas);
		
		JMenuItem mntmRegistroDeUnVisitante = new JMenuItem("Registro de un visitante");
		mntmRegistroDeUnVisitante.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formularioVisitante.setVisible(true);
			}
		});
		mnRegistrar.add(mntmRegistroDeUnVisitante);
		
		JMenuItem mntmRegistroDeParqueSinClasificar = new JMenuItem("Registro de parque sin clasificar");
		mntmRegistroDeParqueSinClasificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formilarioAreaSinCLasificar.setVisible(true);
			}
		});
		mnRegistrar.add(mntmRegistroDeParqueSinClasificar);
		
		JMenu mnConsultar = new JMenu("Consultar");
		menuBar.add(mnConsultar);
		
		JMenu mnMostrarreasProtegidas = new JMenu("Mostrar \u00E1reas protegidas");
		
		mnConsultar.add(mnMostrarreasProtegidas);
		JMenuItem mntmMostrarreasAcuaticas = new JMenuItem("Mostrar \u00E1reas acuaticas");
		mntmMostrarreasAcuaticas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formulariomostrarareaAcuatica.setVisible(true);
			}
		});
		mnMostrarreasProtegidas.add(mntmMostrarreasAcuaticas);
		
		JMenuItem mntmMostrarreasTerrestres = new JMenuItem("Mostrar \u00E1reas terrestres");
		mntmMostrarreasTerrestres.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formulatioMostrarAreaTerrestre.setVisible(true);
			}
		});
		mnMostrarreasProtegidas.add(mntmMostrarreasTerrestres);
		
		JMenuItem mntmMostrarLasReservas = new JMenuItem("Mostrar las reservas de caza");
		mntmMostrarLasReservas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formulariomostrarReservacaza.setVisible(true);
			}
		});
		mnConsultar.add(mntmMostrarLasReservas);
		
		JMenuItem mntmMostrarOtros = new JMenuItem("Mostrar otros");
		mntmMostrarOtros.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formulariomostrarareasinclasificar.setVisible(true);
			}
		});
		mnConsultar.add(mntmMostrarOtros);
		
	}
}
