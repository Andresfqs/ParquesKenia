package Excepciones;
public class VisitarExcepcion extends Exception{
	public VisitarExcepcion ()
	{
		System.out.println("el perque no existe");
	}
}
