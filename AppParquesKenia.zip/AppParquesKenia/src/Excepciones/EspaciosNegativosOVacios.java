package Excepciones;

public class EspaciosNegativosOVacios extends Exception{
	public EspaciosNegativosOVacios()
	{
		System.out.print("nu lleno todos los datos, o lleno alguno con un numero negativo");
	}
}
