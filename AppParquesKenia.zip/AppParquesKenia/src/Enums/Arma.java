package Enums;
public enum Arma {Lanza,Arco,Escopeta}